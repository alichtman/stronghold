class Constants:
	PROJECT_NAME = 'stronghold'
	VERSION = '1.4.1'
	AUTHOR_GITHUB = 'alichtman'
	AUTHOR_FULL_NAME = 'Aaron Lichtman'
	DESCRIPTION = "Securely configure your Mac from the terminal."
	URL = 'https://github.com/alichtman/stronghold',
	AUTHOR_EMAIL = 'aaronlichtman@gmail.com',
